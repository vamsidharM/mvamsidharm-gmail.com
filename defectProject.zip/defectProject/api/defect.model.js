const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define collection and schema for Business
let Defect = new Schema({
  description: {
    type: String
  },
  priority: {
    type: Number
  },
  category: {
    type: String
  },
  status: {
    type: String
  }
},{
    collection: 'defect'
});

module.exports = mongoose.model('Defect', Defect);