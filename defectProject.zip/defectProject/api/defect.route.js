const express = require('express');
const defectRoutes = express.Router();

// Require Business model in our routes module
let Defect = require('./defect.model');

// Defined store route
defectRoutes.route('/add').post(function (req, res) {
    let defect = new Defect(req.body);
    defect.save()
      .then(defect => {
        res.status(200).json({'defect': 'defect in added successfully'});
      })
      .catch(err => {
      res.status(400).send("unable to save to database");
      });
  });

  // Defined get data(index or listing) route
  defectRoutes.route('/view').get(function (req, res) {
    Defect.find(function(err, defects){
    if(err){
      console.log(err);
    }
    else {
      res.json(defects);
    }
  });
});

// Defined edit route
defectRoutes.route('/edit/:id').get(function (req, res) {
    let id = req.params.id;
    Defect.findById(id, function (err, defect){
        res.json(defect);
    });
  });

  defectRoutes.route('/update/:id').post(function (req, res) {
    Defect.findById(req.params.id, function(err, defect) {
    if (!defect)
      res.status(404).send("data is not found");
    else {
        defect.status = req.body.status;
        // business.business_name = req.body.business_name;
        // business.business_gst_number = req.body.business_gst_number;

        defect.save().then(defect => {
          res.json('Update complete');
      })
      .catch(err => {
            res.status(400).send("unable to update the database");
      });
    }
  });
});

  module.exports = defectRoutes;