import React, { Component } from 'react';
import axios from 'axios';

class TableRow extends Component {
    constructor(props){
        super(props);
       this.handleClick=this.handleClick.bind(this);
    }
    
    handleClick=(e)=>{
      e.preventdefault();
      const obj = {
        status: "closed"
      };

      axios.post('http://localhost:4000/defect/update/'+this.props.obj._id, obj)
        .then(res => console.log(res.data));
      console.log(this.props.obj.history);
      
     // this.props.history.push('/view_defects');
     }
  render() {
    return (
     
        <tr>
          <td>
            {this.props.obj.category}
          </td>
          <td>
            {this.props.obj.description}
          </td>
          <td>
            {this.props.obj.priority}
          </td>
          <td>
            {this.props.obj.status}
          </td>
          <td>            
          <a href="/view_defects" onClick={this.handleClick}> 
              Close Defect
              </a> 
          </td>          
        </tr>
    );
  }
}

export default TableRow;