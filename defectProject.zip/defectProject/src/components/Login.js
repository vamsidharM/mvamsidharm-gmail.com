import React from 'react';

const Login = () => {
    return (
        <div>
            Login component
        </div>
    );
};

export default Login;