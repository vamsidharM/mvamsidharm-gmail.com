import React, { Component } from 'react';
import axios from 'axios';

export default class AddDefect extends Component {
  constructor(props) {
    super(props);
    this.onChangeDescription = this.onChangeDescription.bind(this);
    this.onChangePriority = this.onChangePriority.bind(this);
    this.onChangeCategory = this.onChangeCategory.bind(this);
    this.onSubmit = this.onSubmit.bind(this);

    this.state = {
      description: '',
      priority: '',
      business_gst_number:''
    }
  }
  onChangeDescription(e) {
    this.setState({
      description: e.target.value
    });
  }
  onChangePriority(e) {
    this.setState({
      priority: e.target.value
    })  
  }
  onChangeCategory(e) {
    this.setState({
      category: e.target.value
    })
  }

  onSubmit(e) {
    e.preventDefault();
    const obj = {
      description: this.state.description,
      priority: this.state.priority,
      category: this.state.category,
      status:"Open"
    };
    axios.post('http://localhost:4000/defect/add', obj)
        .then(res => console.log(res.data));
    console.log(obj);
    
    this.setState({
      description: '',
      priority: '',
      category: ''
    });
    this.props.history.push('/view_defects');

  }
 
  render() {
    return (
        <div style={{ marginTop: 10 }}>
            <h3>Add Defects</h3>
            <form onSubmit={this.onSubmit}>
            <div className="form-group">
                    <label>Category </label>
                    <select name="category" className="form-control" value={this.state.category}  onChange={this.onChangeCategory} >
                             <option  value='select' >select</option>
                             <option  value='UI defect'>UI defect</option>
                             <option  value='Functional defect'>Functional defect</option>
                             <option  value='Performance defect'>Performance defect</option>
                     </select>
                </div>
                <div className="form-group">
                    <label>Description:  </label>
                    <textarea                        
                      className="form-control" 
                      value={this.state.description}
                      onChange={this.onChangeDescription} placeholder="Enter defect descriptionde"
                      />
                </div>
                <div className="form-group">
                    <label>Priority: </label>
                    <input type="text" 
                      className="form-control"
                      value={this.state.priority}
                      onChange={this.onChangePriority}
                      />
                </div>
               
                <div className="form-group">
                    <input type="submit" value="Add defect" className="btn btn-primary"/>
                </div>
            </form>
        </div>
    )
  }
}
