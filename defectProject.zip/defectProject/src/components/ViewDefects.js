import React, { Component } from 'react';
import axios from 'axios';
import TableRow from './TableRow';

class ViewDefects extends Component {
  constructor(props) {
    super(props);
    this.state = {
      defects: [],
      priority: 0,
      category: ''

    }
    this.handleOnChange = this.handleOnChange.bind(this);
    this.handleCategoryChange = this.handleCategoryChange.bind(this);
  }

  componentDidMount() {
    axios.get('http://localhost:4000/defect/view')
      .then(response => {
        this.setState({ defects: response.data });
      })
      .catch(function (error) {
        console.log(error);
      })
  }

  handleOnChange = (e) => {
    this.setState({
      priority: e.target.value

    })
  }
  handleCategoryChange = (e) => {
    this.setState({
      category: e.target.value

    })
  }

  tabRow() {

    // let filteredElements = this.state.defects.filter((defect, i) => {

    //   if (Number(this.state.priority > 0 && this.state.category !=="select")) 
    //     return defect.priority === Number(this.state.priority) || defect.category === this.state.category 
    // });

    return this.state.defects.map( (object, i)=> {
      if(object.priority === Number(this.state.priority))
      return <TableRow obj={object} key={i} />;     
    });
  }




  render() {

    return (
      <React.Fragment>
        <div><h4 align="center">Filter Details</h4>
          <div>Priority: <select name="priority" className="form-control" value={this.state.priority} onChange={this.handleOnChange}>
            <option value='0' >All</option>
            <option value='1'>1</option>
            <option value='2'>2</option>
            <option value='3'>3</option>
          </select>
          </div><br />
          <div>Category: <select name="category" className="form-control" onChange={this.handleCategoryChange}>
            <option value='ALl' >All</option>
            <option value='UI defect'>UI defect</option>
            <option value='Functional defect'>Functional defect</option>
            <option value='Performance defect'>Performance defect</option>
          </select>
          </div><br />

        </div><br />
        <div>
          <h3 align="center">Defect Details</h3>
          <table className="table table-striped" style={{ marginTop: 20 }}>
            <thead>
              <tr>
                <th>Defect Category</th>
                <th>Description</th>
                <th>Pririoty</th>
                <th>Status</th>
                <th>Change Status</th>
              </tr>
            </thead>
            <tbody>
              {this.tabRow()}

            </tbody>
          </table>
        </div>
      </React.Fragment>
    );
  }
}

export default ViewDefects;