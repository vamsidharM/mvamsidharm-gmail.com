import React, { Component } from 'react';
import {BrowserRouter, Route,Switch, Link} from 'react-router-dom';
import Login from './Login';
import AddDefect from './AddDefect';
import ViewDefects from './ViewDefects';

class Header extends Component {
    render() {
        return (
            <React.Fragment>
            <div>
                Defect  Tracker<br/>
            </div>
            <BrowserRouter>
            <Link to="/Login" >Login </Link><br/><br />
            <Link to="/add_defect" >Add Defect </Link>
            <Link to="/view_defects" >View Defects </Link>
            <Switch>
                <Route exact path="/Login" component={Login} />
                <Route exact path="/Add_defect" component={AddDefect} />
                <Route exact path="/view_defects" component={ViewDefects} />
            </Switch>
            </BrowserRouter>
            </React.Fragment>
        );
    }
}

export default Header;