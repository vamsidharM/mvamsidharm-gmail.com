import React, { Component } from 'react';
import {BrowserRouter as Router,Link,Switch,Route} from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

//components
import Login from './components/Login';
import AddDefect from './components/AddDefect';
import ViewDefects from './components/ViewDefects';

class App extends Component {
    render() {
        return (
        <Router>
            <div className="container">            
           <div><h2>Defect Tracker</h2> </div><br/><br/>
           <nav className="navbar navbar-expand-lg navbar-light bg-light">
             <div className="collapse navbar-collapse" id="navbarSupportedContent">
              <ul className="navbar-nav mr-auto">
              <li className="nav-item">
                  <Link to={'/Login'} className="nav-link">Login</Link>
                </li><br/><br />
                <li className="nav-item">
                  <Link to={'/add_defect'} className="nav-link">Add defect</Link>
                </li>
                <li className="nav-item">
                  <Link to={'/view_defects'} className="nav-link">View Defects</Link>
                </li>
               </ul>
              </div>
             </nav> <br/>
             <Switch>              
              <Route exact path="/Login" component={Login} />
               <Route exact path="/Add_defect" component={AddDefect} />
               <Route exact path="/view_defects" component={ViewDefects} />
             </Switch>
            </div>
        </Router>
        );
    }
}

export default App;